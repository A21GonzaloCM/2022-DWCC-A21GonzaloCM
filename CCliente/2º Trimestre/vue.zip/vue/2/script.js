
const { createApp } = Vue;
    createApp({
        data() {
            return {
                nombre: "Gonzalo CM",
                año: 2023,
                imagen:"https://casa-de-la-pradera-a-bana-es-15863.hotelmix.es/data/Photos/OriginalPhoto/11988/1198811/1198811719/Casa-De-La-Pradera-Villa-A-Bana-Exterior.JPEG",
                contador: 0

            };
        },
    }).mount("#app");
