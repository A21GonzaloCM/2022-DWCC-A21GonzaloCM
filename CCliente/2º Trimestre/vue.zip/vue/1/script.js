
const { createApp } = Vue;
    createApp({
        data() {
            return {
                message: "Hello Vue!",
                int: 1,

            };
        },
    }).mount("#app");
